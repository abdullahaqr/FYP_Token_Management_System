
export { default as IMG01} from '../../../assets/images/patient.jpg';
export { default as IMG02} from '../../../assets/images/patient1.jpg';
export { default as IMG03} from '../../../assets/images/patient2.jpg';
export { default as IMG04} from '../../../assets/images/patient3.jpg';
export { default as IMG05} from '../../../assets/images/patient4.jpg';
export { default as IMG06} from '../../../assets/images/patient5.jpg';
export { default as IMG07} from '../../../assets/images/patient6.jpg';
export { default as IMG08} from '../../../assets/images/patient7.jpg';
export { default as IMG09} from '../../../assets/images/patient8.jpg';
export { default as IMG010} from '../../../assets/images/patient9.jpg';
export { default as IMG011} from '../../../assets/images/patient10.jpg';
export { default as IMG012} from '../../../assets/images/patient11.jpg';

